# Getting Started with Create React App

This project is a test
you run it by launching the cmd: npm start
